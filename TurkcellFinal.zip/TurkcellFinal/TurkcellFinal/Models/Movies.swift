//
//  Movies.swift
//  TurkcellFinal
//
//  Created by selin eylül bilen on 2/20/21.
//

import Foundation

struct MoviesResponse: Decodable{
    let results: [Movies]
}

struct Movies: Decodable, Identifiable{
    let id: Int
    let title: String
    let backdropPath: String?
    let posterPath: String?
    let overview: String?
    let voteAverage: Double
    let voteCount: Int
    let runtime: Int?
    let releaseDate: String?
    
    let genres: [MovieGenre]?
    
    static private let yearFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd/mm/yyyy"
        return formatter
    }()
    
    static private var durationFormatter: DateComponentsFormatter = {
       let formatter = DateComponentsFormatter()
        formatter.unitsStyle = .full
        formatter.allowedUnits = [.hour, .minute]
        return formatter
    }()
    
    var backdropURL: URL{
        return URL(string: "https://image.tmdb.org/t/p/w500\(backdropPath ?? "")")!
    }
    
    var posterURL: URL{
        return URL(string: "https://image.tmdb.org/t/p/w500\(posterPath ?? "")")!
    }
    
    var genreText:String{
        genres?.first?.name ?? "n/a"
    }
    
    var ratingText: String{
        return "⭐️\(voteAverage)/10"
    }

    var yearText: String{
        guard let releaseDate = self.releaseDate, let date = Utils.dateFormatter.date(from: releaseDate) else{
            return "n/a"
        }
        return Movies.yearFormatter.string(from: date)
    }
    
    var durationText: String{
        guard let runtime = self.runtime, runtime > 0 else{
            return "n/a"
        }
        return Movies.durationFormatter.string(from: TimeInterval(runtime) * 60) ?? "n/a"
    }
}

struct MovieGenre: Decodable {
    let name: String
}
